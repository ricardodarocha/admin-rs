<p align="center">
  <a href="https://lusaxweb.github.io/devAwesome/">
    <img width="40%" src="https://github.com/lusaxweb/devAwesome/blob/master/public/png/Asset%2025%40144x.png" alt="vuesax" />
   </a>
 </p>
 
 <h1 align="center">
  <a href="https://lusaxweb.github.io/devAwesome/">
    DevAwesome
   </a>
 </h1>

We are a curated list of everything related to development with a visual representation, our goal is to get the programmers to find the best for their projects and developments, the projects are purified by a minimum of 1000 stars in github and a critique to have the best projects in our network


